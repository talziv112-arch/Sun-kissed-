"use client";

import { useEffect, useState } from "react";
import { searchUsersByPhone, listUsers, updateUserNotes } from "@/lib/services/usersService";
import { listAppointmentsByPhone } from "@/lib/services/appointmentsService";
import type { UserDoc, AppointmentDoc } from "@/lib/types";
import { formatCurrency, formatDateHe } from "@/lib/utils";

export default function CustomersPage() {
  const [users, setUsers] = useState<UserDoc[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selected, setSelected] = useState<UserDoc | null>(null);
  const [history, setHistory] = useState<AppointmentDoc[]>([]);
  const [notes, setNotes] = useState("");
  const [savingNotes, setSavingNotes] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => { (async () => { setUsers(await listUsers()); setLoading(false); })(); }, []);

  async function runSearch() {
    setLoading(true);
    setUsers(await searchUsersByPhone(searchTerm));
    setLoading(false);
  }

  async function openCustomer(u: UserDoc) {
    setSelected(u);
    setNotes(u.notes ?? "");
    setHistory(await listAppointmentsByPhone(u.phone));
  }

  async function saveNotes() {
    if (!selected) return;
    setSavingNotes(true);
    await updateUserNotes(selected.phone, notes);
    setSelected({ ...selected, notes });
    setUsers((prev) => prev.map((x) => (x.phone === selected.phone ? { ...x, notes } : x)));
    setSavingNotes(false);
  }

  const totalSpent = history.filter((a) => a.status !== "cancelled").reduce((s, a) => s + a.price, 0);
  const completedCount = history.filter((a) => a.status !== "cancelled").length;

  return (
    <div>
      <h1 className="mb-5 text-2xl font-bold text-bronze-800">לקוחות</h1>

      <div className="mb-5 flex gap-2">
        <input
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && runSearch()}
          dir="ltr"
          placeholder="חיפוש לפי מספר טלפון…"
          className="flex-1 rounded-xl border border-sand-200 bg-white px-4 py-3 text-bronze-800"
        />
        <button onClick={runSearch} className="rounded-xl bg-amber-deep px-6 py-3 font-semibold text-white shadow-glow hover:bg-bronze-600">חיפוש</button>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_1.4fr]">
        <div className="rounded-2xl border border-sand-200 bg-white/80 shadow-card">
          {loading ? (
            <p className="p-6 text-center text-bronze-400">טוען…</p>
          ) : users.length === 0 ? (
            <p className="p-6 text-center text-bronze-400">לא נמצאו לקוחות.</p>
          ) : (
            <ul className="thin-scroll max-h-[70vh] divide-y divide-sand-100 overflow-y-auto">
              {users.map((u) => (
                <li key={u.phone}>
                  <button onClick={() => openCustomer(u)}
                    className={`flex w-full items-center justify-between px-4 py-3 text-right transition hover:bg-sand-50 ${selected?.phone === u.phone ? "bg-sand-100" : ""}`}>
                    <div>
                      <p className="font-semibold text-bronze-800">{u.displayName}</p>
                      <p className="text-sm text-bronze-500" dir="ltr">{u.phone}</p>
                    </div>
                    <span className="text-bronze-300">‹</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="rounded-2xl border border-sand-200 bg-white/80 p-5 shadow-card">
          {!selected ? (
            <p className="py-16 text-center text-bronze-400">בחרו לקוח לצפייה בכרטיס.</p>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-bronze-800">{selected.displayName}</h2>
                  <p className="text-bronze-500" dir="ltr">{selected.phone}</p>
                </div>
                <div className="text-left">
                  <p className="text-sm text-bronze-500">סה״כ הוצאות</p>
                  <p className="text-lg font-bold text-amber-deep">{formatCurrency(totalSpent)}</p>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3 text-center">
                <div className="rounded-xl bg-sand-50 p-3">
                  <p className="text-2xl font-bold text-bronze-800">{completedCount}</p>
                  <p className="text-xs text-bronze-500">תורים</p>
                </div>
                <div className="rounded-xl bg-sand-50 p-3">
                  <p className="text-2xl font-bold text-bronze-800">{history.filter((a) => a.status === "cancelled").length}</p>
                  <p className="text-xs text-bronze-500">ביטולים</p>
                </div>
              </div>

              <div className="mt-5">
                <label className="text-sm font-medium text-bronze-700">הערות פנימיות</label>
                <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3}
                  className="mt-1 w-full rounded-xl border border-sand-200 bg-white px-3 py-2 text-sm text-bronze-800"
                  placeholder="העדפות, רגישויות, מידע חשוב…" />
                <button onClick={saveNotes} disabled={savingNotes}
                  className="mt-2 rounded-full bg-bronze-600 px-5 py-2 text-sm font-semibold text-white disabled:opacity-50">
                  {savingNotes ? "שומר…" : "שמירת הערות"}
                </button>
              </div>

              <h3 className="mt-6 mb-2 text-sm font-bold text-bronze-700">היסטוריית תורים</h3>
              {history.length === 0 ? (
                <p className="text-sm text-bronze-400">אין היסטוריה.</p>
              ) : (
                <div className="thin-scroll max-h-72 space-y-2 overflow-y-auto">
                  {history.map((a) => (
                    <div key={a.id} className="flex items-center justify-between rounded-xl border border-sand-100 px-3 py-2 text-sm">
                      <div>
                        <span className="font-medium text-bronze-700">{a.serviceName}</span>
                        <span className="mx-2 text-bronze-300">·</span>
                        <span className="text-bronze-500">{formatDateHe(a.date)} {a.startTime}</span>
                      </div>
                      <span className={a.status === "cancelled" ? "text-red-500" : "text-amber-deep"}>
                        {a.status === "cancelled" ? "בוטל" : formatCurrency(a.price)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
