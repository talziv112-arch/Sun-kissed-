"use client";

import { useEffect, useState } from "react";
import { getSettings, saveSettings, DEFAULT_SETTINGS } from "@/lib/services/settingsService";
import type { BusinessSettings } from "@/lib/types";
import { WEEKDAYS_HE } from "@/lib/utils";

export default function SettingsPage() {
  const [settings, setSettings] = useState<BusinessSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => { (async () => { setSettings(await getSettings()); setLoading(false); })(); }, []);

  function toggleDay(day: number) {
    setSettings((s) => ({
      ...s,
      workingDays: s.workingDays.includes(day)
        ? s.workingDays.filter((d) => d !== day)
        : [...s.workingDays, day].sort((a, b) => a - b),
    }));
  }

  async function handleSave() {
    setBusy(true); setSaved(false);
    await saveSettings(settings);
    setBusy(false); setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  if (loading) return <p className="text-bronze-500">טוען…</p>;

  return (
    <div className="max-w-2xl">
      <h1 className="mb-5 text-2xl font-bold text-bronze-800">הגדרות עסק</h1>

      <div className="space-y-5">
        <Card title="שעות פעילות">
          <div className="grid grid-cols-2 gap-4">
            <Field label="שעת פתיחה">
              <input type="time" value={settings.openTime} onChange={(e) => setSettings({ ...settings, openTime: e.target.value })} dir="ltr" className="input" />
            </Field>
            <Field label="שעת סגירה">
              <input type="time" value={settings.closeTime} onChange={(e) => setSettings({ ...settings, closeTime: e.target.value })} dir="ltr" className="input" />
            </Field>
          </div>
        </Card>

        <Card title="ימי פעילות">
          <div className="flex flex-wrap gap-2">
            {WEEKDAYS_HE.map((w, i) => {
              const on = settings.workingDays.includes(i);
              return (
                <button key={w} onClick={() => toggleDay(i)}
                  className={`rounded-full px-4 py-2 text-sm font-medium transition ${on ? "bg-amber-deep text-white shadow-glow" : "border border-sand-200 bg-white text-bronze-600"}`}>
                  {w}
                </button>
              );
            })}
          </div>
        </Card>

        <Card title="כללי הזמנה">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Field label="מרווח משבצות (דקות)">
              <input type="number" min={5} step={5} value={settings.slotGranularity} onChange={(e) => setSettings({ ...settings, slotGranularity: Number(e.target.value) })} dir="ltr" className="input" />
            </Field>
            <Field label="זמן חיץ בין תורים (דקות)">
              <input type="number" min={0} step={5} value={settings.bufferMinutes} onChange={(e) => setSettings({ ...settings, bufferMinutes: Number(e.target.value) })} dir="ltr" className="input" />
            </Field>
            <Field label="תפוסה יומית מרבית">
              <input type="number" min={1} value={settings.maxDailyCapacity} onChange={(e) => setSettings({ ...settings, maxDailyCapacity: Number(e.target.value) })} dir="ltr" className="input" />
            </Field>
          </div>
        </Card>

        <div className="flex items-center gap-3">
          <button onClick={handleSave} disabled={busy} className="rounded-full bg-amber-deep px-8 py-3 font-semibold text-white shadow-glow disabled:opacity-50">
            {busy ? "שומר…" : "שמירת הגדרות"}
          </button>
          {saved && <span className="text-sm font-medium text-green-600">✓ ההגדרות נשמרו</span>}
        </div>
      </div>

      <style>{`.input{width:100%;border-radius:0.75rem;border:1px solid #EBD9BF;background:#fff;padding:0.6rem 0.9rem;color:#3A2A1A}`}</style>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-sand-200 bg-white/80 p-5 shadow-card">
      <h2 className="mb-4 text-lg font-bold text-bronze-800">{title}</h2>
      {children}
    </section>
  );
}
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (<label className="block"><span className="mb-1.5 block text-sm font-medium text-bronze-700">{label}</span>{children}</label>);
}
