import type { Timestamp } from "firebase/firestore";

export interface UserDoc {
  phone: string;          // normalized, also the document id
  displayName: string;
  passwordHash: string;   // salt:hash (PBKDF2)
  notes?: string;         // admin-only notes
  createdAt: number;      // epoch ms
}

export interface ServiceDoc {
  id: string;
  name: string;
  durationMinutes: number;
  price: number;          // ILS
  description?: string;
  active: boolean;
  createdAt: number;
}

export type AppointmentStatus = "booked" | "cancelled" | "completed";

export interface AppointmentDoc {
  id: string;
  userPhone: string;
  userName: string;
  serviceId: string;
  serviceName: string;
  price: number;
  date: string;           // YYYY-MM-DD
  startTime: string;      // HH:MM (24h)
  endTime: string;        // HH:MM (24h)
  durationMinutes: number;
  status: AppointmentStatus;
  source: "client" | "admin";
  notes?: string;
  createdAt: number;
}

export interface BusinessSettings {
  openTime: string;       // HH:MM
  closeTime: string;      // HH:MM
  slotGranularity: number;// minutes (booking grid)
  bufferMinutes: number;  // buffer after each appointment
  maxDailyCapacity: number;
  workingDays: number[];  // 0=Sunday ... 6=Saturday
  updatedAt: number;
}

export interface BlockedDateDoc {
  id: string;             // YYYY-MM-DD or YYYY-MM-DD_HH:MM
  date: string;           // YYYY-MM-DD
  startTime?: string;     // optional time range (whole day if absent)
  endTime?: string;
  reason?: string;
  createdAt: number;
}

export interface WaitingListDoc {
  id: string;
  userPhone: string;
  userName: string;
  serviceId: string;
  serviceName: string;
  preferredDate: string;  // YYYY-MM-DD
  status: "waiting" | "notified" | "resolved";
  createdAt: number;
}

export interface SlotLockDoc {
  id: string;             // YYYY-MM-DD_HH:MM
  appointmentId: string;
  createdAt: Timestamp | number;
}
