import { doc, getDoc, setDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import type { BusinessSettings } from "@/lib/types";

const COL = "settings";
const DOC_ID = "business";

export const DEFAULT_SETTINGS: BusinessSettings = {
  openTime: "09:00",
  closeTime: "20:00",
  slotGranularity: 15,
  bufferMinutes: 0,
  maxDailyCapacity: 40,
  workingDays: [0, 1, 2, 3, 4, 5], // Sun–Fri
  updatedAt: 0,
};

export async function getSettings(): Promise<BusinessSettings> {
  const snap = await getDoc(doc(db, COL, DOC_ID));
  if (!snap.exists()) return DEFAULT_SETTINGS;
  return { ...DEFAULT_SETTINGS, ...(snap.data() as Partial<BusinessSettings>) };
}

export async function saveSettings(settings: BusinessSettings): Promise<void> {
  await setDoc(doc(db, COL, DOC_ID), { ...settings, updatedAt: Date.now() });
}
