// Client authentication: PHONE + PASSWORD only. No email anywhere.
// Users are stored in Firestore (doc id = normalized phone). Passwords are
// salted + PBKDF2-hashed. Session persists in localStorage.

import { getUserByPhone, createUser } from "@/lib/services/usersService";
import { hashPassword, verifyPassword } from "@/lib/hash";
import { normalizePhone, isValidPhone } from "@/lib/utils";
import type { UserDoc } from "@/lib/types";

const SESSION_KEY = "sunkissed_client_session";

export interface ClientSession {
  phone: string;
  displayName: string;
}

export async function registerClient(
  phone: string,
  password: string,
  displayName: string
): Promise<ClientSession> {
  if (!isValidPhone(phone)) throw new Error("מספר טלפון לא תקין");
  if (password.length < 4) throw new Error("הסיסמה חייבת להכיל לפחות 4 תווים");
  const id = normalizePhone(phone);

  const existing = await getUserByPhone(id);
  if (existing) throw new Error("מספר הטלפון כבר רשום במערכת");

  const passwordHash = await hashPassword(password);
  const user: UserDoc = {
    phone: id,
    displayName: displayName.trim() || id,
    passwordHash,
    createdAt: Date.now(),
  };
  await createUser(user);

  const session: ClientSession = { phone: id, displayName: user.displayName };
  persistSession(session);
  return session;
}

export async function loginClient(phone: string, password: string): Promise<ClientSession> {
  if (!isValidPhone(phone)) throw new Error("מספר טלפון לא תקין");
  const user = await getUserByPhone(phone);
  if (!user) throw new Error("מספר הטלפון אינו רשום במערכת");
  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) throw new Error("סיסמה שגויה");

  const session: ClientSession = { phone: user.phone, displayName: user.displayName };
  persistSession(session);
  return session;
}

export function persistSession(session: ClientSession): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}

export function getSession(): ClientSession | null {
  if (typeof window === "undefined") return null;
  const raw = window.localStorage.getItem(SESSION_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as ClientSession;
  } catch {
    return null;
  }
}

export function clearSession(): void {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(SESSION_KEY);
}
